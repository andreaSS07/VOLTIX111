# VOLTIX ⚡ — Come ottenere l'APK

## PASSO 1 — Crea account GitHub (se non ce l'hai)
1. Vai su https://github.com
2. Clicca "Sign up" → inserisci email, password, username
3. Verifica l'email

## PASSO 2 — Crea il repository
1. Una volta loggato su GitHub, clicca il "+" in alto a destra
2. Clicca "New repository"
3. In "Repository name" scrivi: voltix
4. Seleziona "Public"
5. NON spuntare nessuna altra opzione (no README, no .gitignore)
6. Clicca "Create repository"

## PASSO 3 — Carica i file
1. Nella pagina del repository appena creato vedi scritto
   "uploading an existing file" — clicca su quella scritta
2. Apri Esplora File sul tuo PC
3. Vai dentro la cartella VOLTIX_FINALE che hai estratto dallo zip
4. Seleziona TUTTI i file e cartelle dentro VOLTIX_FINALE
   (pubspec.yaml, lib, android, .github)
5. ATTENZIONE: su Windows le cartelle che iniziano con punto
   come ".github" potrebbero essere nascoste.
   Per vederle: Esplora File → Visualizza → spunta "Elementi nascosti"
6. Trascina tutto nella pagina GitHub
7. Aspetta che finisca di caricare
8. In basso clicca "Commit changes"

## PASSO 4 — Avvia la build
1. Clicca su "Actions" nel menu in alto del repository
2. Se vedi un messaggio "Workflows aren't being run on this fork"
   clicca "I understand my workflows, go ahead and enable them"
3. Nel menu a sinistra clicca "Build VOLTIX APK"
4. Clicca il bottone "Run workflow" → "Run workflow"
5. Aggiorna la pagina dopo 10 secondi

## PASSO 5 — Scarica l'APK
1. Aspetta circa 10-15 minuti
2. Quando appare un cerchio verde ✅ la build è finita
3. Clicca sul nome della build "Build VOLTIX APK"
4. Scorri TUTTO in basso fino a "Artifacts"
5. Clicca "VOLTIX-APK" → scarica lo zip
6. Estrai lo zip → dentro c'è "app-debug.apk"

## PASSO 6 — Installa sul telefono
1. Manda l'APK al telefono (WhatsApp a te stesso, email, USB)
2. Sul telefono apri il file
3. Se chiede "Consenti installazione da sorgenti sconosciute" → OK
4. Installa → VOLTIX è pronto!

## PASSO 7 — Configura Firebase (OBBLIGATORIO)
Senza questo il login non funziona:
1. Vai su console.firebase.google.com
2. Authentication → Metodi di accesso → Email/Password → ABILITA
3. Authentication → Metodi di accesso → Google → ABILITA
4. Firestore Database → Crea database → Modalità test
5. Firestore → Regole → incolla questo e pubblica:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
