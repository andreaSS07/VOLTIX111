import 'package:flutter/material.dart';
class V {
  static const orange = Color(0xFFFFA500);
  static const bg     = Color(0xFF0A0A0A);
  static const bg2    = Color(0xFF111111);
  static const bg3    = Color(0xFF1A1A1A);
  static const muted  = Color(0xFF666666);
  static const red    = Color(0xFFFF3333);
  static const border = Color(0x14FFFFFF);
  static TextStyle ops(double s, {Color c = Colors.white, double ls = 0}) =>
      TextStyle(fontFamily: 'BlackOpsOne', fontSize: s, color: c, letterSpacing: ls);
  static TextStyle bar(double s, {Color c = Colors.white, FontWeight w = FontWeight.w700, double ls = 0}) =>
      TextStyle(fontFamily: 'BarlowCondensed', fontSize: s, color: c, fontWeight: w, letterSpacing: ls);
}
class Tier {
  final String name; final int min, max; final int? nextAt; final String? nextName;
  const Tier(this.name, this.min, this.max, this.nextAt, this.nextName);
  static const all = [Tier('SPARK',0,50,51,'CHARGE'),Tier('CHARGE',51,200,201,'OVERLOAD'),Tier('OVERLOAD',201,500,501,'THUNDER'),Tier('THUNDER',501,999999,null,null)];
  static Tier of(int v) => all.firstWhere((t) => v >= t.min && v <= t.max, orElse: () => all.first);
  double progress(int v) => nextAt == null ? 1.0 : ((v - min) / (nextAt! - min)).clamp(0.0, 1.0);
}
const CL_CLOUD  = 'dsczmzamv';
const CL_PRESET = 'rmy6kf0q';
const ADMIN_PWD = 'Holsucaa96518jollysurfaru@@';
