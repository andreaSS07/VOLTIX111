import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'controllers/auth_controller.dart';
import 'controllers/session_controller.dart';
import 'controllers/feed_controller.dart';
import 'screens/loading_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0A0A0A),
  ));
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyAWpI0vOE_0lJwwO7u1t17yuDaW56KrckE',
      authDomain: 'volt-e55e7.firebaseapp.com',
      projectId: 'volt-e55e7',
      storageBucket: 'volt-e55e7.firebasestorage.app',
      messagingSenderId: '353773432588',
      appId: '1:353773432588:web:8792bdf8adc7aec3b72329',
    ),
  );
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => AuthController()),
      ChangeNotifierProvider(create: (_) => SessionController()),
      ChangeNotifierProvider(create: (_) => FeedController()),
    ],
    child: const VoltixApp(),
  ));
}

class VoltixApp extends StatelessWidget {
  const VoltixApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VOLTIX',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF0A0A0A),
      primaryColor: const Color(0xFFFFA500),
    ),
    home: const LoadingScreen(),
  );
}
