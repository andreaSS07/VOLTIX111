import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum AuthStatus { loading, out, in_ }

class AuthController extends ChangeNotifier {
  final _auth   = FirebaseAuth.instance;
  final _db     = FirebaseFirestore.instance;
  final _google = GoogleSignIn();
  AuthStatus status = AuthStatus.loading;
  User? user;
  String? username;
  String? photoUrl;
  String? err;

  AuthController() {
    _auth.authStateChanges().listen((u) async {
      user = u;
      if (u != null) { await _load(u.uid); status = AuthStatus.in_; }
      else { status = AuthStatus.out; username = null; }
      notifyListeners();
    });
  }

  Future<void> _load(String uid) async {
    try {
      final s = await _db.collection('users').doc(uid).get();
      if (s.exists) { username = s.data()?['username'] ?? user?.displayName; photoUrl = s.data()?['photoURL'] ?? user?.photoURL; }
      else { username = user?.displayName; photoUrl = user?.photoURL; }
    } catch (_) {}
  }

  Future<void> register(String un, String em, String pw) async {
    err = null;
    try {
      final c = await _auth.createUserWithEmailAndPassword(email: em, password: pw);
      await _db.collection('users').doc(c.user!.uid).set({
        'username': un, 'email': em, 'photoURL': '',
        'voltsReceived': 0, 'voltsGiven': 0, 'videoPassed': 0, 'uploadsToday': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });
      username = un;
    } on FirebaseAuthException catch (e) { err = _e(e.code); notifyListeners(); rethrow; }
  }

  Future<void> login(String em, String pw) async {
    err = null;
    try { await _auth.signInWithEmailAndPassword(email: em, password: pw); }
    on FirebaseAuthException catch (e) { err = _e(e.code); notifyListeners(); rethrow; }
  }

  Future<void> google() async {
    try {
      final ga = await _google.signIn();
      if (ga == null) return;
      final a = await ga.authentication;
      final c = GoogleAuthProvider.credential(accessToken: a.accessToken, idToken: a.idToken);
      final r = await _auth.signInWithCredential(c);
      await _db.collection('users').doc(r.user!.uid).set({
        'username': r.user!.displayName ?? 'USER', 'email': r.user!.email ?? '',
        'photoURL': r.user!.photoURL ?? '',
        'voltsReceived': 0, 'voltsGiven': 0, 'videoPassed': 0, 'uploadsToday': 0,
      }, SetOptions(merge: true));
    } catch (e) { err = e.toString(); notifyListeners(); }
  }

  Future<void> signOut() async { await _google.signOut(); await _auth.signOut(); }

  String _e(String c) => const {
    'email-already-in-use':'Email già registrata', 'invalid-email':'Email non valida',
    'weak-password':'Password troppo corta (min 6)', 'user-not-found':'Utente non trovato',
    'wrong-password':'Password errata', 'invalid-credential':'Email o password errati',
    'too-many-requests':'Troppi tentativi',
  }[c] ?? 'Errore: $c';
}
