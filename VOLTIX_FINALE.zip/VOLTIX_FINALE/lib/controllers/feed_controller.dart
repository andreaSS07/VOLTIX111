import 'dart:math';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Video {
  final String id, authorUid, authorUsername, videoUrl, challengeText;
  final String? authorPhoto;
  const Video({required this.id, required this.authorUid, required this.authorUsername, required this.videoUrl, required this.challengeText, this.authorPhoto});
  factory Video.from(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>;
    return Video(id: d.id, authorUid: m['authorUid']??'', authorUsername: m['authorUsername']??'???', videoUrl: m['videoUrl']??'', challengeText: m['challengeText']??'', authorPhoto: m['authorPhoto']);
  }
}

class FeedController extends ChangeNotifier {
  List<Video> videos = []; int idx = 0; bool loading = false; String? votedName;
  Video? get current => idx < videos.length ? videos[idx] : null;

  Future<void> load() async {
    loading = true; notifyListeners();
    try {
      final myUid = FirebaseAuth.instance.currentUser?.uid;
      final s = await FirebaseFirestore.instance.collection('videos').orderBy('createdAt', descending: true).limit(60).get();
      videos = s.docs.map((d) => Video.from(d)).where((v) => v.authorUid != myUid).toList()..shuffle(Random());
      idx = 0;
    } catch (_) {}
    loading = false; notifyListeners();
  }

  void advance() { idx++; votedName = null; notifyListeners(); if (idx >= videos.length) load(); }
  void setVoted(String n) { votedName = n; notifyListeners(); }
}
