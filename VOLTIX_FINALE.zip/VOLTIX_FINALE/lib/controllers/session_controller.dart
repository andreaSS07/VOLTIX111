import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SessionController extends ChangeNotifier {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  DateTime? exp;
  String challenge = 'Mostra il tuo talento in 11 secondi';
  int vR = 0, vG = 0, vP = 0, up = 0;
  String timer = '--:--:--';
  Timer? _t;
  StreamSubscription? _sub;
  String? get uid => _auth.currentUser?.uid;
  bool get active => exp != null && exp!.isAfter(DateTime.now());

  Future<void> load() async {
    if (uid == null) return;
    final s = await _db.collection('users').doc(uid).get();
    if (!s.exists) return;
    final d = s.data()!;
    vR = d['voltsReceived'] ?? 0; vG = d['voltsGiven'] ?? 0;
    vP = d['videoPassed'] ?? 0; up = d['uploadsToday'] ?? 0;
    if (d['sessionExpiresAt'] != null) exp = (d['sessionExpiresAt'] as Timestamp).toDate();
    await _loadCh(); _startTimer(); _subStats(); notifyListeners();
  }

  Future<void> start() async {
    if (uid == null) return;
    final e = DateTime.now().add(const Duration(hours: 24));
    exp = e; vR = vG = vP = up = 0;
    await _db.collection('users').doc(uid).set({
      'sessionExpiresAt': Timestamp.fromDate(e),
      'voltsReceived': 0, 'voltsGiven': 0, 'videoPassed': 0, 'uploadsToday': 0,
    }, SetOptions(merge: true));
    await _loadCh(); _startTimer(); _subStats(); notifyListeners();
  }

  Future<void> end() async {
    _t?.cancel(); _sub?.cancel(); exp = null;
    await _db.collection('users').doc(uid).set({'sessionExpiresAt': null}, SetOptions(merge: true));
    notifyListeners();
  }

  Future<void> _loadCh() async {
    final key = DateTime.now().toIso8601String().substring(0, 10);
    try { final s = await _db.collection('challenges').doc(key).get(); if (s.exists) challenge = s.data()!['text'] ?? challenge; } catch (_) {}
  }

  void _subStats() {
    _sub?.cancel();
    _sub = _db.collection('users').doc(uid).snapshots().listen((s) {
      if (!s.exists) return;
      final d = s.data()!;
      vR = d['voltsReceived'] ?? 0; vG = d['voltsGiven'] ?? 0;
      vP = d['videoPassed'] ?? 0; up = d['uploadsToday'] ?? 0;
      notifyListeners();
    });
  }

  void _startTimer() {
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (exp == null) return;
      final d = exp!.difference(DateTime.now());
      if (d.isNegative) { exp = null; timer = '00:00:00'; notifyListeners(); return; }
      timer = '${d.inHours.toString().padLeft(2,'0')}:${(d.inMinutes%60).toString().padLeft(2,'0')}:${(d.inSeconds%60).toString().padLeft(2,'0')}';
      notifyListeners();
    });
  }

  Future<void> volt(String videoId, String authorUid) async {
    if (uid == null) return;
    final inc = FieldValue.increment(1);
    await Future.wait([
      _db.collection('videos').doc(videoId).set({'voltCount': inc}, SetOptions(merge: true)),
      _db.collection('users').doc(authorUid).set({'voltsReceived': inc}, SetOptions(merge: true)),
      _db.collection('users').doc(uid).set({'voltsGiven': inc}, SetOptions(merge: true)),
    ]);
  }

  Future<void> pass() async {
    if (uid == null) return;
    await _db.collection('users').doc(uid).set({'videoPassed': FieldValue.increment(1)}, SetOptions(merge: true));
  }

  @override void dispose() { _t?.cancel(); _sub?.cancel(); super.dispose(); }
}
