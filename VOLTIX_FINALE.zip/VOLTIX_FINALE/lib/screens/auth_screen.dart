import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/auth_controller.dart';
import '../theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _S();
}
class _S extends State<AuthScreen> {
  bool _reg = true, _busy = false;
  final _un = TextEditingController(), _em = TextEditingController(), _pw = TextEditingController();
  final _lem = TextEditingController(), _lpw = TextEditingController();
  String _err = '';
  static const _adj  = ['STORM','NEON','VOLT','FLUX','SURGE','THUNDER','WIRE'];
  static const _noun = ['HAWK','WOLF','KING','QUEEN','RIDER','ZERO','GHOST'];
  void _rnd() { final r = DateTime.now().millisecondsSinceEpoch; _un.text = '${_adj[r%_adj.length]}_${_noun[(r~/100)%_noun.length]}${(r%99)+1}'; setState((){}); }

  Future<void> _doReg() async {
    final un = _un.text.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9_]'),'');
    setState(() => _err = '');
    if (un.length < 3) { setState(() => _err = 'Callsign: minimo 3 caratteri'); return; }
    if (_em.text.isEmpty) { setState(() => _err = 'Inserisci email'); return; }
    if (_pw.text.length < 6) { setState(() => _err = 'Password: minimo 6 caratteri'); return; }
    setState(() => _busy = true);
    try { await context.read<AuthController>().register(un, _em.text.trim(), _pw.text); }
    catch (_) { setState(() => _err = context.read<AuthController>().err ?? 'Errore'); }
    setState(() => _busy = false);
  }

  Future<void> _doLog() async {
    setState(() => _err = '');
    if (_lem.text.isEmpty || _lpw.text.isEmpty) { setState(() => _err = 'Inserisci email e password'); return; }
    setState(() => _busy = true);
    try { await context.read<AuthController>().login(_lem.text.trim(), _lpw.text); }
    catch (_) { setState(() => _err = context.read<AuthController>().err ?? 'Errore'); }
    setState(() => _busy = false);
  }

  Future<void> _doGoogle() async { setState(() => _busy = true); await context.read<AuthController>().google(); setState(() => _busy = false); }

  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: V.bg, body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(children: [
    Text('VOLTIX', style: V.ops(38, c: V.orange, ls: 2)),
    const SizedBox(height: 4),
    Text('24H · VIDEO · COMPETE', style: V.bar(12, c: V.muted, ls: 4)),
    const SizedBox(height: 28),
    if (_reg) ...[
      Text('CREA ACCOUNT', style: V.ops(14, c: V.orange, ls: 2)), const SizedBox(height: 14),
      Row(children: [Expanded(child: _inp(_un, 'CALLSIGN (ES. STORM99)', cap: true)), const SizedBox(width: 8),
        GestureDetector(onTap: _rnd, child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          decoration: BoxDecoration(color: V.bg3, borderRadius: BorderRadius.circular(4), border: Border.all(color: V.border, width: 2)),
          child: Text('RND', style: V.bar(13, c: V.muted, ls: 1))))]),
      const SizedBox(height: 10),
      _inp(_em, 'Email', type: TextInputType.emailAddress), const SizedBox(height: 10),
      _inp(_pw, 'Password (min 6 caratteri)', obs: true), const SizedBox(height: 14),
      _bigBtn('REGISTRATI', _busy ? null : _doReg),
    ] else ...[
      Text('ACCEDI', style: V.ops(14, c: V.orange, ls: 2)), const SizedBox(height: 14),
      _inp(_lem, 'Email', type: TextInputType.emailAddress), const SizedBox(height: 10),
      _inp(_lpw, 'Password', obs: true), const SizedBox(height: 14),
      _bigBtn('ENTRA', _busy ? null : _doLog),
    ],
    if (_err.isNotEmpty) ...[const SizedBox(height: 8), Text(_err, style: V.bar(13, c: V.red), textAlign: TextAlign.center)],
    const SizedBox(height: 12),
    Row(children: [Expanded(child: Container(height: 1, color: V.border)), Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('OPPURE', style: V.bar(11, c: V.muted, ls: 2))), Expanded(child: Container(height: 1, color: V.border))]),
    const SizedBox(height: 12),
    SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _busy ? null : _doGoogle,
      style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black87, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
      child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : Text('ACCEDI CON GOOGLE', style: V.bar(15, c: Colors.black87, ls: 1)))),
    const SizedBox(height: 16),
    GestureDetector(onTap: () => setState(() { _reg = !_reg; _err = ''; }),
      child: Text(_reg ? 'Hai già un account? Accedi' : 'Non hai un account? Registrati', style: V.bar(13, c: V.muted, ls: 1))),
  ])))));

  Widget _inp(TextEditingController c, String h, {TextInputType type = TextInputType.text, bool obs = false, bool cap = false}) =>
    TextField(controller: c, keyboardType: type, obscureText: obs, textCapitalization: cap ? TextCapitalization.characters : TextCapitalization.none,
      style: V.bar(16, ls: 1),
      decoration: InputDecoration(hintText: h, hintStyle: V.bar(15, c: V.muted), filled: true, fillColor: V.bg3,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: V.border, width: 2)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: V.orange, width: 2)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13)));

  Widget _bigBtn(String l, VoidCallback? f) => SizedBox(width: double.infinity, child: ElevatedButton(onPressed: f,
    style: ElevatedButton.styleFrom(backgroundColor: V.orange, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
    child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : Text(l, style: V.ops(17, c: Colors.black, ls: 2))));
}
