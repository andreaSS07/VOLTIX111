import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../controllers/feed_controller.dart';
import '../controllers/session_controller.dart';
import '../theme.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override State<FeedScreen> createState() => _S();
}
class _S extends State<FeedScreen> {
  VideoPlayerController? _vpc;
  bool _flash = false;
  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => context.read<FeedController>().load()); }
  @override void dispose() { _vpc?.dispose(); super.dispose(); }

  Future<void> _play(String url) async {
    await _vpc?.dispose();
    _vpc = VideoPlayerController.networkUrl(Uri.parse(url));
    await _vpc!.initialize();
    _vpc!.setLooping(true); _vpc!.play();
    if (mounted) setState(() {});
  }

  Future<void> _volt(Video v) async {
    setState(() => _flash = true);
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) setState(() => _flash = false);
    final feed = context.read<FeedController>();
    final sess = context.read<SessionController>();
    feed.setVoted(v.authorUsername);
    await sess.volt(v.id, v.authorUid);
    await Future.delayed(const Duration(milliseconds: 700));
    feed.advance();
    if (feed.current != null) _play(feed.current!.videoUrl);
  }

  Future<void> _pass() async {
    final feed = context.read<FeedController>();
    await context.read<SessionController>().pass();
    feed.advance();
    if (feed.current != null) _play(feed.current!.videoUrl);
  }

  @override
  Widget build(BuildContext context) {
    final feed = context.watch<FeedController>();
    final sess = context.watch<SessionController>();
    return Stack(children: [
      _body(feed, sess),
      if (_flash) Positioned.fill(child: IgnorePointer(child: Container(color: V.orange.withOpacity(0.13)))),
    ]);
  }

  Widget _body(FeedController feed, SessionController sess) {
    if (feed.loading) return const Center(child: CircularProgressIndicator(color: V.orange));
    final v = feed.current;
    if (v == null) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text('HAI VISTO TUTTO', style: V.ops(22, c: V.orange)),
      const SizedBox(height: 8), Text('Nessun video per ora', style: V.bar(14, c: V.muted, ls: 1)),
      const SizedBox(height: 20),
      ElevatedButton(onPressed: feed.load, style: ElevatedButton.styleFrom(backgroundColor: V.orange, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
        child: Text('RICARICA', style: V.ops(14, c: Colors.black, ls: 2))),
    ]));
    return ListView(padding: const EdgeInsets.fromLTRB(14,0,14,96), children: [
      Container(margin: const EdgeInsets.only(top:10,bottom:8), padding: const EdgeInsets.symmetric(horizontal:13,vertical:9),
        decoration: BoxDecoration(color: V.orange.withOpacity(.1), border: Border.all(color: V.orange.withOpacity(.28)), borderRadius: BorderRadius.circular(6)),
        child: Text('SFIDA DI OGGI: ${sess.challenge}', style: V.bar(13, c: V.orange, ls: 1))),
      if (feed.votedName != null)
        Container(margin: const EdgeInsets.only(bottom:8), padding: const EdgeInsets.symmetric(horizontal:13,vertical:10),
          decoration: BoxDecoration(color: V.orange.withOpacity(.12), border: Border.all(color: V.orange.withOpacity(.35)), borderRadius: BorderRadius.circular(6)),
          child: Text('Voltix dato a ${feed.votedName}!', textAlign: TextAlign.center, style: V.bar(14, c: V.orange, ls: 1))),
      _Card(key: ValueKey(v.id), v: v, vpc: _vpc, ch: sess.challenge, onVolt: () => _volt(v), onPass: _pass),
    ]);
  }
}

class _Card extends StatelessWidget {
  final Video v; final VideoPlayerController? vpc; final String ch; final VoidCallback onVolt, onPass;
  const _Card({super.key, required this.v, this.vpc, required this.ch, required this.onVolt, required this.onPass});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: V.bg2, border: Border.all(color: V.border), borderRadius: BorderRadius.circular(8)),
    clipBehavior: Clip.hardEdge,
    child: Column(children: [
      AspectRatio(aspectRatio: 9/16, child: Stack(fit: StackFit.expand, children: [
        vpc?.value.isInitialized == true ? VideoPlayer(vpc!) : Container(color: const Color(0xFF120a1e), child: const Center(child: CircularProgressIndicator(color: V.orange, strokeWidth: 2))),
        Positioned(top:11,right:11, child: Container(padding: const EdgeInsets.symmetric(horizontal:9,vertical:3),
          decoration: BoxDecoration(color: Colors.black.withOpacity(.75), borderRadius: BorderRadius.circular(3), border: Border.all(color: Colors.white12)),
          child: Text('11s', style: V.bar(12, c: V.orange, ls: 1)))),
        Positioned(bottom:0,left:0,right:0, child: Container(
          padding: const EdgeInsets.fromLTRB(14,26,14,14),
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87])),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SFIDA DI OGGI', style: V.bar(10, c: V.orange, ls: 3)), const SizedBox(height:3),
            Text(v.challengeText.isNotEmpty ? v.challengeText : ch, style: V.bar(16)),
          ]))),
      ])),
      Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        Row(children: [
          CircleAvatar(radius:15, backgroundColor:V.orange,
            backgroundImage: (v.authorPhoto??'').isNotEmpty ? NetworkImage(v.authorPhoto!) : null,
            child: (v.authorPhoto??'').isEmpty ? Text(v.authorUsername.isNotEmpty?v.authorUsername[0]:'?', style: V.ops(12,c:Colors.black)) : null),
          const SizedBox(width:9), Text(v.authorUsername, style: V.bar(15, ls:1)),
        ]),
        const SizedBox(height:11),
        Row(children: [
          Expanded(child: ElevatedButton(onPressed: onVolt, style: ElevatedButton.styleFrom(backgroundColor:V.orange,foregroundColor:Colors.black,padding:const EdgeInsets.symmetric(vertical:15),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4))), child: Text('VOLTIX', style: V.ops(15,c:Colors.black,ls:2)))),
          const SizedBox(width:9),
          Expanded(child: OutlinedButton(onPressed: onPass, style: OutlinedButton.styleFrom(side:const BorderSide(color:V.border),foregroundColor:V.muted,padding:const EdgeInsets.symmetric(vertical:15),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4))), child: Text('PASS', style: V.ops(15,c:V.muted,ls:2)))),
        ]),
      ])),
    ]),
  );
}
