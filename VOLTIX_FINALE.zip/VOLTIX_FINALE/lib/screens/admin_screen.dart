import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../theme.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override State<AdminScreen> createState() => _S();
}
class _S extends State<AdminScreen> {
  final _ctrl = TextEditingController();
  String _ok='', _err=''; bool _saving=false;
  List<Map<String,String>> _hist=[];
  String get _key => DateTime.now().toIso8601String().substring(0,10);

  @override void initState() { super.initState(); _load(); }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    final s = await FirebaseFirestore.instance.collection('challenges').doc(_key).get();
    if(s.exists) setState(()=>_ctrl.text=s.data()!['text']??'');
    final h = await FirebaseFirestore.instance.collection('challenges').orderBy(FieldPath.documentId,descending:true).limit(10).get();
    setState(()=>_hist=h.docs.map((d)=>{'date':d.id,'text':(d.data()['text']??'') as String}).toList());
  }

  Future<void> _save() async {
    final txt=_ctrl.text.trim();
    if(txt.isEmpty){setState(()=>_err='Scrivi la sfida');return;}
    setState(()=>_saving=true);
    try {
      await FirebaseFirestore.instance.collection('challenges').doc(_key).set({'text':txt,'updatedAt':FieldValue.serverTimestamp()});
      setState(()=>_ok='Sfida salvata!');
      await _load();
    } catch(e){setState(()=>_err='Errore: $e');}
    setState(()=>_saving=false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: V.bg,
    appBar: AppBar(backgroundColor:V.bg, title:Text('ADMIN VOLTIX',style:V.ops(18,c:V.orange,ls:2)), iconTheme:const IconThemeData(color:V.orange),
      bottom:PreferredSize(preferredSize:const Size.fromHeight(1),child:Container(height:1,color:V.border))),
    body: ListView(padding:const EdgeInsets.all(16), children:[
      Container(padding:const EdgeInsets.all(16),
        decoration:BoxDecoration(color:V.bg2,border:Border.all(color:V.border),borderRadius:BorderRadius.circular(8)),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('SFIDA DI OGGI',style:V.ops(14,c:V.orange,ls:2)),
          const SizedBox(height:4),
          Text(_key,style:V.bar(13,c:V.muted,ls:1)),
          const SizedBox(height:12),
          TextField(controller:_ctrl,maxLines:3,style:V.bar(16),
            decoration:InputDecoration(hintText:'Scrivi la sfida di oggi...',hintStyle:V.bar(15,c:V.muted),filled:true,fillColor:V.bg3,
              border:OutlineInputBorder(borderRadius:BorderRadius.circular(4),borderSide:BorderSide.none),
              enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(4),borderSide:const BorderSide(color:V.border,width:2)),
              focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(4),borderSide:const BorderSide(color:V.orange,width:2)),
              contentPadding:const EdgeInsets.all(13))),
          const SizedBox(height:8),
          if(_ok.isNotEmpty) Text(_ok,style:V.bar(13,c:const Color(0xFF00CC66))),
          if(_err.isNotEmpty) Text(_err,style:V.bar(13,c:V.red)),
          const SizedBox(height:10),
          SizedBox(width:double.infinity,child:ElevatedButton(onPressed:_saving?null:_save,
            style:ElevatedButton.styleFrom(backgroundColor:V.orange,foregroundColor:Colors.black,padding:const EdgeInsets.symmetric(vertical:14),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4))),
            child:_saving?const SizedBox(height:20,width:20,child:CircularProgressIndicator(strokeWidth:2,color:Colors.black)):Text('SALVA SFIDA',style:V.ops(16,c:Colors.black,ls:2)))),
        ])),
      const SizedBox(height:14),
      Container(padding:const EdgeInsets.all(16),
        decoration:BoxDecoration(color:V.bg2,border:Border.all(color:V.border),borderRadius:BorderRadius.circular(8)),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('SFIDE PRECEDENTI',style:V.ops(14,c:V.orange,ls:2)),
          const SizedBox(height:12),
          if(_hist.isEmpty) Text('Nessuna sfida ancora',style:V.bar(13,c:V.muted))
          else ..._hist.map((h)=>Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(10),
            decoration:BoxDecoration(color:V.bg3,borderRadius:BorderRadius.circular(4)),
            child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(h['date']!,style:V.bar(12,c:V.orange,ls:1)),
              const SizedBox(width:10),
              Expanded(child:Text(h['text']!,style:V.bar(13))),
            ]))),
        ])),
    ]),
  );
}
