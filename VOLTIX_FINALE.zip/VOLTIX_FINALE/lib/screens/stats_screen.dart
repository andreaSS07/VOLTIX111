import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/session_controller.dart';
import '../controllers/auth_controller.dart';
import '../theme.dart';
import 'admin_screen.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final sess = context.watch<SessionController>();
    final auth = context.watch<AuthController>();
    final tier = Tier.of(sess.vR);
    return ListView(padding: const EdgeInsets.fromLTRB(14,14,14,96), children: [
      Container(padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: V.orange.withOpacity(.07), border: Border.all(color: V.orange.withOpacity(.18)), borderRadius: BorderRadius.circular(8)),
        child: Column(children: [
          CircleAvatar(radius:32, backgroundColor:V.orange,
            backgroundImage: (auth.photoUrl??'').isNotEmpty?NetworkImage(auth.photoUrl!):null,
            child: (auth.photoUrl??'').isEmpty?Text((auth.username??'?')[0],style:V.ops(24,c:Colors.black)):null),
          const SizedBox(height:8),
          Text(auth.username??'—', style: V.ops(24, ls:2)),
          const SizedBox(height:4),
          Text(tier.name, style: V.bar(12, c:V.orange, ls:3)),
          const SizedBox(height:12),
          Text('${sess.vR}', style: V.ops(58, c:V.orange)),
          Text('VOLTIX RICEVUTI', style: V.bar(11, c:V.muted, ls:3)),
        ])),
      const SizedBox(height:10),
      Container(padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color:V.bg2, border:Border.all(color:V.border), borderRadius:BorderRadius.circular(8)),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('PROSSIMO TIER', style: V.bar(11, c:V.muted, ls:2)),
            Text(tier.nextAt!=null?'${sess.vR} / ${tier.nextAt}':'MAX TIER', style: V.bar(11, c:V.muted, ls:2)),
          ]),
          const SizedBox(height:8),
          ClipRRect(borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(value: tier.progress(sess.vR), minHeight:5, backgroundColor:V.bg3, valueColor:const AlwaysStoppedAnimation(V.orange))),
          const SizedBox(height:6),
          Align(alignment: Alignment.centerLeft,
            child: Text(tier.nextAt!=null?'Prossimo: ${tier.nextName} a ${tier.nextAt} Voltix':'Sei al massimo!', style: V.bar(12, c:V.muted, ls:1))),
        ])),
      const SizedBox(height:10),
      GridView.count(crossAxisCount:2, shrinkWrap:true, physics:const NeverScrollableScrollPhysics(), mainAxisSpacing:8, crossAxisSpacing:8, childAspectRatio:1.8,
        children: [_box('${sess.vG}','VIDEO VOTATI'), _box('${sess.vP}','PASSATI'), _box('${sess.up}','CARICATI'), _box(sess.timer,'SCADE TRA')]),
      const SizedBox(height:10),
      OutlinedButton(onPressed: ()=>_openAdmin(context),
        style: OutlinedButton.styleFrom(side:BorderSide(color:V.orange.withOpacity(.3)), foregroundColor:V.orange, padding:const EdgeInsets.symmetric(vertical:12), shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4))),
        child: Text('PANNELLO ADMIN', style: V.bar(12, c:V.orange, ls:2))),
      const SizedBox(height:8),
      OutlinedButton(onPressed: () async { if(await _confirm(context,'Resettare la sessione?')) await context.read<SessionController>().end(); },
        style: OutlinedButton.styleFrom(side:const BorderSide(color:V.border), foregroundColor:V.muted, padding:const EdgeInsets.symmetric(vertical:12), shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4))),
        child: Text('RESET SESSIONE', style: V.bar(12, c:V.muted, ls:2))),
      const SizedBox(height:8),
      OutlinedButton(onPressed: () async { if(await _confirm(context,'Disconnettersi?')) await context.read<AuthController>().signOut(); },
        style: OutlinedButton.styleFrom(side:BorderSide(color:V.red.withOpacity(.3)), foregroundColor:V.red, padding:const EdgeInsets.symmetric(vertical:12), shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4))),
        child: Text('DISCONNETTI', style: V.bar(12, c:V.red, ls:2))),
    ]);
  }

  Widget _box(String v, String l) => Container(padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color:V.bg2, border:Border.all(color:V.border), borderRadius:BorderRadius.circular(6)),
    child: Column(crossAxisAlignment:CrossAxisAlignment.start, mainAxisAlignment:MainAxisAlignment.center, children: [
      Text(v, style: V.ops(24)), Text(l, style: V.bar(10, c:V.muted, ls:2))]));

  Future<bool> _confirm(BuildContext ctx, String msg) async =>
    await showDialog<bool>(context:ctx, builder:(c)=>AlertDialog(backgroundColor:V.bg2, title:Text(msg,style:V.bar(16)),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:Text('NO',style:V.bar(14,c:V.muted))),
        TextButton(onPressed:()=>Navigator.pop(c,true),child:Text('SÌ',style:V.bar(14,c:V.orange)))])) ?? false;

  void _openAdmin(BuildContext ctx) {
    final pw = TextEditingController(); String err='';
    showDialog(context:ctx, builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(backgroundColor:V.bg2,
      title:Text('ACCESSO ADMIN',style:V.ops(16,c:V.orange,ls:2)),
      content:Column(mainAxisSize:MainAxisSize.min, children:[
        TextField(controller:pw, obscureText:true, style:V.bar(15),
          decoration:InputDecoration(hintText:'Password admin',hintStyle:V.bar(14,c:V.muted),filled:true,fillColor:V.bg3,border:OutlineInputBorder(borderRadius:BorderRadius.circular(4),borderSide:BorderSide.none))),
        if(err.isNotEmpty)...[const SizedBox(height:8),Text(err,style:V.bar(13,c:V.red))],
      ]),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(c),child:Text('ANNULLA',style:V.bar(13,c:V.muted))),
        TextButton(onPressed:(){if(pw.text==ADMIN_PWD){Navigator.pop(c);Navigator.push(ctx,MaterialPageRoute(builder:(_)=>const AdminScreen()));}else{ss(()=>err='Password errata');}},child:Text('ENTRA',style:V.bar(14,c:V.orange))),
      ])));
  }
}
