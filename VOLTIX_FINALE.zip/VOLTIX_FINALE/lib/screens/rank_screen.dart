import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../theme.dart';

class RankScreen extends StatelessWidget {
  const RankScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').orderBy('voltsReceived', descending: true).limit(100).snapshots(),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: V.orange));
        final docs = snap.data?.docs ?? [];
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(14,14,14,96),
          itemCount: docs.length + 1,
          itemBuilder: (ctx, i) {
            if (i == 0) return Padding(padding: const EdgeInsets.only(bottom:12),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('CLASSIFICA', style: V.ops(26, c: V.orange)),
                Text(DateTime.now().toIso8601String().substring(0,10), style: V.bar(12, c: V.muted, ls: 2)),
              ]));
            final d = docs[i-1]; final u = d.data() as Map<String,dynamic>;
            final rank = i; final isMe = d.id == myUid; final volts = u['voltsReceived'] ?? 0;
            final pos = rank<=3 ? ['1°','2°','3°'][rank-1] : '#$rank';
            return Container(margin: const EdgeInsets.only(bottom:3), padding: const EdgeInsets.symmetric(horizontal:8,vertical:8),
              decoration: BoxDecoration(color: isMe?V.orange.withOpacity(.07):Colors.transparent, border: isMe?Border.all(color:V.orange.withOpacity(.2)):null, borderRadius: BorderRadius.circular(4)),
              child: Row(children: [
                SizedBox(width:28, child: Text(pos, textAlign: TextAlign.center, style: V.ops(13, c: rank<=3?V.orange:V.muted))),
                const SizedBox(width:10),
                CircleAvatar(radius:16, backgroundColor:V.orange,
                  backgroundImage: (u['photoURL']??'').isNotEmpty ? NetworkImage(u['photoURL']) : null,
                  child: (u['photoURL']??'').isEmpty ? Text((u['username']??'?')[0], style: V.ops(12,c:Colors.black)) : null),
                const SizedBox(width:11),
                Expanded(child: Text('${u['username']??'???'}${isMe?' (TU)':''}', style: V.bar(14, c: isMe?V.orange:Colors.white, ls:1), overflow: TextOverflow.ellipsis)),
                Text('$volts VX', style: V.bar(14, c: V.orange, ls:1)),
              ]));
          });
      });
  }
}
