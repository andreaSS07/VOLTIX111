import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../controllers/session_controller.dart';
import '../controllers/auth_controller.dart';
import '../theme.dart';

class RecordScreen extends StatefulWidget {
  const RecordScreen({super.key});
  @override State<RecordScreen> createState() => _S();
}
class _S extends State<RecordScreen> {
  CameraController? _cam; List<CameraDescription> _cams = []; int _ci = 0;
  bool _ready=false,_rec=false,_hasRec=false,_up=false; String? _path; int _left=11;
  Timer? _t; String _info='MAX 11 SECONDI · SOLO SFIDE · NO GALLERIA';

  @override void initState() { super.initState(); _init(); }
  @override void dispose() { _t?.cancel(); _cam?.dispose(); super.dispose(); }

  Future<void> _init() async {
    try {
      _cams = await availableCameras(); if (_cams.isEmpty) return;
      final fi = _cams.indexWhere((c) => c.lensDirection == CameraLensDirection.front);
      _ci = fi >= 0 ? fi : 0; await _startCam(_ci);
    } catch (e) { setState(() => _info='Errore cam: $e'); }
  }

  Future<void> _startCam(int i) async {
    await _cam?.dispose();
    _cam = CameraController(_cams[i], ResolutionPreset.high, enableAudio: true);
    await _cam!.initialize(); if (mounted) setState(() => _ready=true);
  }

  Future<void> _flip() async {
    if (_rec||_cams.length<2) return; setState(()=>_ready=false);
    final bi=_cams.indexWhere((c)=>c.lensDirection==CameraLensDirection.back);
    final fi=_cams.indexWhere((c)=>c.lensDirection==CameraLensDirection.front);
    _ci=_ci==fi?(bi>=0?bi:0):(fi>=0?fi:0); await _startCam(_ci);
  }

  Future<void> _startRec() async {
    if(!_ready||_rec||_cam==null) return;
    await _cam!.startVideoRecording();
    setState((){_rec=true;_hasRec=false;_left=11;_info='REGISTRAZIONE IN CORSO...';});
    _t=Timer.periodic(const Duration(seconds:1),(t) async {
      if(!mounted){t.cancel();return;} setState(()=>_left--);
      if(_left<=0){t.cancel();await _stopRec();}
    });
  }

  Future<void> _stopRec() async {
    _t?.cancel(); if(!_rec||_cam==null) return;
    final xf=await _cam!.stopVideoRecording();
    setState((){_rec=false;_hasRec=true;_path=xf.path;_info='VIDEO PRONTO — ${11-_left}S';});
  }

  void _redo() { if(_path!=null) try{File(_path!).deleteSync();}catch(_){} setState((){_hasRec=false;_path=null;_info='MAX 11 SECONDI · SOLO SFIDE · NO GALLERIA';}); }

  Future<void> _publish() async {
    if(_path==null) return; setState((){_up=true;_info='CARICAMENTO...';});
    try {
      final sess=context.read<SessionController>(); final auth=context.read<AuthController>();
      final req=http.MultipartRequest('POST',Uri.parse('https://api.cloudinary.com/v1_1/$CL_CLOUD/video/upload'));
      req.fields['upload_preset']=CL_PRESET; req.fields['resource_type']='video';
      req.files.add(await http.MultipartFile.fromPath('file',_path!));
      final res=await req.send(); final body=await res.stream.bytesToString(); final data=jsonDecode(body);
      if(res.statusCode!=200) throw Exception(data['error']?['message']??'Upload fallito');
      await FirebaseFirestore.instance.collection('videos').add({
        'authorUid':FirebaseAuth.instance.currentUser!.uid,'authorUsername':auth.username??'???',
        'authorPhoto':auth.photoUrl??'','videoUrl':data['secure_url'],
        'challengeText':sess.challenge,'voltCount':0,'isActive':true,'createdAt':FieldValue.serverTimestamp(),
      });
      await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid)
        .set({'uploadsToday':FieldValue.increment(1)},SetOptions(merge:true));
      _redo();
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:const Text('Video pubblicato! Aspetta i Voltix...'),backgroundColor:V.orange.withOpacity(.9)));
    } catch(e){setState(()=>_info='Errore: $e');}
    setState(()=>_up=false);
  }

  @override
  Widget build(BuildContext context) {
    final ch=context.watch<SessionController>().challenge;
    return ListView(padding:const EdgeInsets.fromLTRB(14,14,14,96),children:[
      Container(decoration:BoxDecoration(color:V.bg2,border:Border.all(color:V.border),borderRadius:BorderRadius.circular(8)),clipBehavior:Clip.hardEdge,
        child:Column(children:[
          AspectRatio(aspectRatio:9/16,child:Stack(fit:StackFit.expand,children:[
            _ready&&_cam!=null?CameraPreview(_cam!):Container(color:Colors.black,child:const Center(child:CircularProgressIndicator(color:V.orange))),
            Positioned.fill(child:CustomPaint(painter:_Grid())),
            if(_rec) Positioned(top:12,left:12,child:_Badge()),
            if(_rec) Positioned(top:12,left:0,right:0,child:Center(child:Text('$_left',style:TextStyle(fontFamily:'BlackOpsOne',fontSize:46,color:V.orange,shadows:[Shadow(color:V.orange.withOpacity(.7),blurRadius:16)])))),
            Positioned(bottom:0,left:0,right:0,child:LinearProgressIndicator(value:_rec?(11-_left)/11:0,minHeight:4,backgroundColor:Colors.white10,valueColor:const AlwaysStoppedAnimation(V.orange))),
            if(_ready&&!_rec&&_cams.length>1) Positioned(bottom:14,right:14,child:GestureDetector(onTap:_flip,
              child:Container(width:44,height:44,decoration:BoxDecoration(color:Colors.black.withOpacity(.65),shape:BoxShape.circle,border:Border.all(color:Colors.white24)),
                child:const Icon(Icons.flip_camera_android,color:Colors.white,size:22)))),
          ])),
          Padding(padding:const EdgeInsets.all(14),child:Column(children:[
            Container(width:double.infinity,padding:const EdgeInsets.all(12),margin:const EdgeInsets.only(bottom:12),
              decoration:BoxDecoration(color:V.orange.withOpacity(.09),border:Border.all(color:V.orange.withOpacity(.25)),borderRadius:BorderRadius.circular(4)),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('SFIDA DI OGGI — UGUALE PER TUTTI',style:V.bar(10,c:V.orange,ls:3)),const SizedBox(height:3),Text(ch,style:V.bar(15))])),
            if(!_hasRec&&!_rec) _btn('REGISTRA',V.red,Colors.white,_ready&&!_up?_startRec:null),
            if(_rec) _btn('STOP',V.bg3,Colors.white,_stopRec,border:V.border),
            if(_hasRec&&!_up)...[_btn('PUBBLICA ORA',V.orange,Colors.black,_publish),const SizedBox(height:8),_btn('RIPRENDI',Colors.transparent,V.muted,_redo,border:V.border,fs:13)],
            if(_up) const Padding(padding:EdgeInsets.symmetric(vertical:16),child:CircularProgressIndicator(color:V.orange)),
            const SizedBox(height:8),
            Text(_info,textAlign:TextAlign.center,style:V.bar(11,c:V.muted,ls:1)),
          ])),
        ])),
    ]);
  }

  Widget _btn(String l,Color bg,Color fg,VoidCallback? f,{Color? border,double fs=16})=>
    SizedBox(width:double.infinity,child:ElevatedButton(onPressed:f,
      style:ElevatedButton.styleFrom(backgroundColor:bg,foregroundColor:fg,padding:const EdgeInsets.symmetric(vertical:15),elevation:0,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(4),side:border!=null?BorderSide(color:border):BorderSide.none)),
      child:Text(l,style:V.ops(fs,c:fg,ls:2))));
}

class _Badge extends StatefulWidget { @override State<_Badge> createState()=>_BS(); }
class _BS extends State<_Badge> with SingleTickerProviderStateMixin {
  late AnimationController _a;
  @override void initState(){super.initState();_a=AnimationController(vsync:this,duration:const Duration(milliseconds:600))..repeat(reverse:true);}
  @override void dispose(){_a.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4),decoration:BoxDecoration(color:V.red,borderRadius:BorderRadius.circular(3)),
    child:Row(mainAxisSize:MainAxisSize.min,children:[FadeTransition(opacity:_a,child:Container(width:7,height:7,decoration:const BoxDecoration(color:Colors.white,shape:BoxShape.circle))),const SizedBox(width:5),Text('REC',style:V.bar(12,ls:2))]));
}

class _Grid extends CustomPainter {
  @override void paint(Canvas c,Size s){final p=Paint()..color=V.orange.withOpacity(.05)..strokeWidth=0.5;for(int i=1;i<3;i++){c.drawLine(Offset(s.width*i/3,0),Offset(s.width*i/3,s.height),p);c.drawLine(Offset(0,s.height*i/3),Offset(s.width,s.height*i/3),p);}}
  @override bool shouldRepaint(_)=>false;
}
