import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/session_controller.dart';
import '../controllers/auth_controller.dart';
import '../theme.dart';

class StartScreen extends StatelessWidget {
  const StartScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: V.orange,
    body: SafeArea(child: Center(child: Padding(padding: const EdgeInsets.all(40), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Spacer(),
      const Text('VOLT\nIX', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'BlackOpsOne', fontSize: 90, color: Color(0xFF0A0A0A), height: 0.88, letterSpacing: -4)),
      const SizedBox(height: 20),
      Text('24H · VIDEO · COMPETE', style: V.bar(14, c: Colors.black45, ls: 6)),
      const Spacer(),
      SizedBox(width: double.infinity, child: ElevatedButton(
        onPressed: () => context.read<SessionController>().start(),
        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0A0A0A), foregroundColor: V.orange, padding: const EdgeInsets.symmetric(vertical: 20), elevation: 8, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
        child: Text('START', style: V.ops(28, c: V.orange, ls: 4)))),
      const SizedBox(height: 14),
      Text('NUOVA SFIDA OGNI 24 ORE', style: V.bar(12, c: Colors.black45, ls: 3)),
      const SizedBox(height: 16),
      TextButton(onPressed: () => context.read<AuthController>().signOut(), child: Text('Disconnetti', style: V.bar(13, c: Colors.black38))),
    ])))));
}
