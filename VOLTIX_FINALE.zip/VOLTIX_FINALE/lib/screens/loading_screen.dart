import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/auth_controller.dart';
import '../controllers/session_controller.dart';
import '../theme.dart';
import 'auth_screen.dart';
import 'start_screen.dart';
import 'shell.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});
  @override State<LoadingScreen> createState() => _S();
}
class _S extends State<LoadingScreen> with SingleTickerProviderStateMixin {
  late AnimationController _a;
  @override void initState() { super.initState(); _a = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true); }
  @override void dispose() { _a.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    if (auth.status == AuthStatus.loading) return Scaffold(backgroundColor: V.bg, body: Center(child: FadeTransition(opacity: _a, child: Text('VOLTIX', style: V.ops(44, c: V.orange, ls: 2)))));
    if (auth.status == AuthStatus.out) return const AuthScreen();
    return Consumer<SessionController>(builder: (_, sess, __) {
      WidgetsBinding.instance.addPostFrameCallback((_) async { if (!sess.active) await sess.load(); });
      if (sess.active) return const Shell();
      return const StartScreen();
    });
  }
}
