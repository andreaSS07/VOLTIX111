import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/session_controller.dart';
import '../theme.dart';
import 'feed_screen.dart';
import 'record_screen.dart';
import 'rank_screen.dart';
import 'stats_screen.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _S();
}
class _S extends State<Shell> {
  int _tab = 0;
  static const _screens = [FeedScreen(), RecordScreen(), RankScreen(), StatsScreen()];
  @override
  Widget build(BuildContext context) {
    final t = context.watch<SessionController>().timer;
    return Scaffold(
      backgroundColor: V.bg,
      body: Column(children: [
        SafeArea(bottom: false, child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: V.border))),
          child: Row(children: [Text('VOLTIX', style: V.ops(20, c: V.orange, ls: 2)), const Spacer(), Text(t, style: V.bar(13, c: V.orange, ls: 1))]))),
        Expanded(child: _screens[_tab]),
      ]),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: Color(0xFF080808), border: Border(top: BorderSide(color: V.border))),
        child: SafeArea(top: false, child: Row(children: [
          _nb(0, Icons.bolt, 'FEED'), _nb(1, Icons.videocam, 'REGISTRA'), _nb(2, Icons.emoji_events, 'RANK'), _nb(3, Icons.person, 'IO'),
        ])),
      ),
    );
  }
  Widget _nb(int i, IconData icon, String label) => Expanded(child: GestureDetector(
    onTap: () => setState(() => _tab = i), behavior: HitTestBehavior.opaque,
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: _tab == i ? V.orange : V.muted, size: 22),
      const SizedBox(height: 2),
      Text(label, style: V.bar(10, c: _tab == i ? V.orange : V.muted, ls: 2)),
    ]))));
}
