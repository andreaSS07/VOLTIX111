package com.voltix.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
